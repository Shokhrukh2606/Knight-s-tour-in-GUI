/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queen;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Odinabonu
 */
public class Queen extends JFrame {
public static void main(String [] args)
{
    int n=8;
    enumerate(n);
}
    public static boolean isConsistent(int [] q, int n)
    {
        for(int i=0; i<n;i++)
        {
            if(q[i]==q[n]) return false;
            if((q[i]-q[n])==(n-i)) return false;
            if((q[i]-q[n])==(n-i)) return false;
        }
        return true;
    }
    public static void printQueens(int q[])
    {
        int n=q.length;
        for(int i=0; i<n;i++)
        {
            for(int j=0; j<n;j++)
            {
                if(q[i]==j)System.out.print("Q");
                else System.out.print("*");
            }
            System.out.println();
        }
        System.out.println();
    }
    public static void enumerate(int n)
    {
        int[] a=new int[n];
        enumerate(a, 0);
    }
    public static void enumerate(int[]q, int k)
    {
        int n=q.length;
        if(k==n) printQueens(q);
        else 
        {
            for(int i=0; i<n;i++)
            {
                q[k]=i;
                if(isConsistent(q, k)) enumerate(q, k+1);
            }
        }
    }
//    private Image brownBoard;
//    private Image whiteBoard;
//    private JPanel centerPanel = new JPanel();
//    private JPanel southPanel = new JPanel();
//    private JPanel westPanel = new JPanel();
//    private JPanel northPanel = new JPanel();
//    private JLabel[] labels;
//    private ImagePanel[] panels;
//    private int rowPos, colPos;
//    public static int i;
//    public static int buttoncounter = 0;
//    public static String[] goodpositions;
//
//    //constructors  
//    public Queen(Image boardImage1, Image boardImage2, int size, int ksize) {
//        this.i = ksize;
//        this.labels = new JLabel[size * size];
//        this.panels = new ImagePanel[size * size];
//        this.brownBoard = boardImage1;
//        this.whiteBoard = boardImage2;
//        showGUI(size);
//    }
//
//    public void showGUI(int size) {
//
//        setTitle("Knight`s tour");
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setSize(1000, 1000);
//        setLocationRelativeTo(null);
//        setVisible(true);
//        addComponentsToPane(getContentPane(), size);
//    }
//
//    private void addPanelsAndLabels(int size) {
//
//        //call methd to create panels with backgound images and appropriate names
//        addPanelsAndImages(size);
//
//        for (int i = 0; i <panels.length ; i++) {
//            labels[i] = new JLabel();
//
//            //used to know the postion of the label on the board
//            labels[i].setName(panels[i].getName());
//
//            panels[i].add(labels[i]);
//
//            //adds panels created in addPanelsAndImages()
//            centerPanel.add(panels[i]);
//        }
//    }
//
//    //this method will create panels with backround images of chess board and set its name according to 1-8 for rows and A-H for coloumns
//    private void addPanelsAndImages(int size) {
//        int count = 0;
//        String[] label = {"Z", "Y", "X", "W", "V", "U", "T", "S", "R", "Q", "P", "O", "N", "M", "L", "K", "J", "I", "H", "G", "F", "E", "D", "C", "B", "A"};
//        int[] num = {26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
//        int i = 26 - size;
//        int j = 26 - size;
//        int c=size;
//        for (int row = 25; row >= i; row--) {
//
//            for (int col = 25; col >= j; col--) {
//                if ((col + row) % 2 == 0) {//even numbers get white pieces
//                    panels[count] = new ImagePanel(brownBoard);
//                } else {//odd numbers get black pieces
//                    panels[count] = new ImagePanel(whiteBoard);
//                }
//
//                panels[count].setName(label[col] + c);
//                count++;
//            }
//            c--;
//        }
//    }
//public void showPanelsAndLabels()
//{
//    for(int i=0; i < panels.length; i++)
//        {
//            System.out.println(panels[i].getName());
//        }
//    System.out.println("labels");
//    for(int i=0; i < panels.length; i++)
//        {
//            System.out.println(labels[i].getName());
//        }
//}
//    private void addComponentsToPane(Container contentPane, int size) {
//        GridLayout gridLayout = new GridLayout(size, size);
//        centerPanel.setLayout(gridLayout);
//
//        //call mehod to add labels to south panel
//        addLabelsToSouthPanel(size);
//        //call method to add oanels to west panel
//        addLabelsToWestPanel(size);
//        //call method to add panels and labels to the center panel which holds the board
//        addPanelsAndLabels(size);
////call method to add button to northpanel
//        addLabelsToNorthPanel();
//
////add all panels to frame
//        contentPane.add(northPanel, BorderLayout.NORTH);
//        contentPane.add(centerPanel, BorderLayout.CENTER);
//        contentPane.add(southPanel, BorderLayout.SOUTH);
//        contentPane.add(westPanel, BorderLayout.WEST);
//    }
//
//    private void addLabelsToNorthPanel() {
//        northPanel.setLayout(new FlowLayout());
//        northPanel.setSize(300, 200);
//        JButton next = new JButton("Next Position!");
//        next.setBounds(20, 20, 40, 20);
//        ButtonHandler hana = new ButtonHandler();
//        next.addActionListener(hana);
//        northPanel.add(next);
//
//    }
//
//    private class ButtonHandler implements ActionListener {
//
//        public void actionPerformed(ActionEvent event) {
//
//            try {
//                addPiece(new ImageIcon(ImageIO.read(new File("src\\x.png")).getScaledInstance(80, 80, Image.SCALE_SMOOTH)), goodpositions[buttoncounter]);
//                addPiece(new ImageIcon(ImageIO.read(new File("src\\knight.png")).getScaledInstance(80, 80, Image.SCALE_SMOOTH)), goodpositions[buttoncounter + 1]);
//                buttoncounter++;
//
//            } catch (IOException ex) {
//                ex.printStackTrace();
//            }
//
//        }
//    }
//
//    private void addLabelsToWestPanel(int size) {
//        GridLayout gridLayout = new GridLayout(size, 0);
//
//        westPanel.setLayout(gridLayout);
//        JLabel[] lbls = new JLabel[size];
//        int[] num = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26};
//        int c = 0;
//        while (size > 0) {
//            lbls[c] = new JLabel(num[size - 1] + " ");
//            westPanel.add(lbls[c]);
//            size--;
//        }
//    }
//
//    private void addLabelsToSouthPanel(int size) {
//        GridLayout gridLayout = new GridLayout(0, size);
//
//        southPanel.setLayout(gridLayout);
//        JLabel[] lbls = new JLabel[size];
//        String[] label = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
//
//        for (int i = 0; i < size; i++) {
//            lbls[i] = new JLabel(label[i] + "");
//            southPanel.add(lbls[i]);
//        }
//    }
//
//    //method sets image of a label at a certain position in the board according to the block name i.e D4
//    public void addPiece(ImageIcon img, String block) {
//        for (int s = 0; s < labels.length; s++) {
//            if (labels[s].getName().equalsIgnoreCase(block)) {
//                labels[s].setIcon(img);
//            }
//        }
//    }
//
////nested class used to set the background of frame contenPane
//    class ImagePanel extends JPanel {
//
//        private Image image;
//
//        /**
//         * Default constructor used to set the image for the background for the
//         * instance
//         */
//        public ImagePanel(Image img) {
//            image = img;
//        }
//
//        @Override
//        protected void paintComponent(Graphics g) {
//            //draws image to background to scale of frame
//            g.drawImage(image, 0, 0, null);
//        }
//    }
}

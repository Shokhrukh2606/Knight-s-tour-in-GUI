/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chessboardtry;

import static chessboardtry.Chessboard.buttoncounter;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author 1710134
 */
public class InterFace extends JFrame {

    private static String[] cols = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
    public int rowposinlogic, colposinlogic;
    private static final int FRAME_WIDTH = 300;
    private static final int FRAME_HEIGHT = 300;
    private static final int FRAME_X_ORIGIN = 150;
    private static final int FRAME_Y_ORIGIN = 250;
    
    private final String ENTER = "Enter";
    private final String BLANK = "";

    private final JTextField dimension, rowPosition, columnPosition;
    private final JPanel informationPanel, buttonPanel;
    public int size;
    public static String nextPos;
    public static int cpos;
    public InterFace() {
        Container contentPane;
        setTitle("Knight Tour");
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        contentPane = getContentPane();
        contentPane.setLayout(new GridLayout(2, 1));
        informationPanel = new JPanel();
        buttonPanel = new JPanel();
        informationPanel.setBorder(BorderFactory.createTitledBorder("Write size, position, knight as(8 a 1): "));
        buttonPanel.setBorder(BorderFactory.createTitledBorder("Write size and position of knight: "));
        JButton b = new JButton(ENTER);
        rowPosition = new JTextField(2);
        columnPosition = new JTextField(2);
        dimension = new JTextField(2);
        ButtonHandler handler = new ButtonHandler();
        b.addActionListener(handler);
        informationPanel.add(dimension);
        informationPanel.add(columnPosition);
        informationPanel.add(rowPosition);
        buttonPanel.add(b);
        contentPane.add(informationPanel);
        contentPane.add(buttonPanel);
        setLocation(50, 250);
        setSize(400, 400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
 new InterFace();

    }

    public void setSize(int s) {
        this.size = s;
    }

    private class ButtonHandler implements ActionListener {

        public void actionPerformed(ActionEvent event) {
            String position = columnPosition.getText() + rowPosition.getText();
            String columnInString = columnPosition.getText();
            for (int i = 0; i < cols.length; i++) {
                if (columnInString.equals(cols[i])) {
                    rowposinlogic = i+1;
                }
            }
            
            String rowinString = rowPosition.getText();
            colposinlogic = Integer.parseInt(rowinString) - 1;
            String s = dimension.getText();            
            int size = Integer.parseInt(s);
            setSize(size);
            try {

                Image brownBlock = ImageIO.read(new File("src\\brown.png"));
                Image whiteBlock = ImageIO.read(new File("src\\white.png"));

                Knightlogic k= new Knightlogic(whiteBlock, brownBlock, size, size, colposinlogic, rowposinlogic);
                k.doLogic();
                k.lastLogic();
                k.showNormalizedArrayResult();
                k.addPiece(new ImageIcon(ImageIO.read(new File("src\\knight.png")).getScaledInstance(80, 80, Image.SCALE_SMOOTH)), position);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chessboardtry;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.imageio.ImageIO;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author U1710134
 */
class Chessboard extends JFrame {

    private Image brownBoard;
    private Image whiteBoard;
    private JPanel centerPanel = new JPanel();
    private JPanel southPanel = new JPanel();
    private JPanel westPanel = new JPanel();
    private JPanel northPanel = new JPanel();
    private JLabel[] labels;
    private ImagePanel[] panels;
    private int rowPos, colPos;
    public static int i;
    public static int buttoncounter = 0;
    public static String[] goodpositions;

    //constructors
    public Chessboard(Image boardImage1, Image boardImage2, int size, int ksize) {
        this.i = ksize;
        this.labels = new JLabel[size * size];
        this.panels = new ImagePanel[size * size];
        this.brownBoard = boardImage1;
        this.whiteBoard = boardImage2;
        showGUI(size);
    }

    public void showGUI(int size) {

        setTitle("Knight`s tour");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 1000);
        setLocationRelativeTo(null);
        setVisible(true);
        addComponentsToPane(getContentPane(), size);
    }

    private void addPanelsAndLabels(int size) {

        //call methd to create panels with backgound images and appropriate names
        addPanelsAndImages(size);

        for (int i = 0; i < panels.length; i++) {
            labels[i] = new JLabel();

            //used to know the postion of the label on the board
            labels[i].setName(panels[i].getName());

            panels[i].add(labels[i]);

            //adds panels created in addPanelsAndImages()
            centerPanel.add(panels[i]);
        }
    }

    //this method will create panels with backround images of chess board and set its name according to 1-8 for rows and A-H for coloumns
    private void addPanelsAndImages(int size) {
        int count = 0;
        int j = 7;
        int i = 0;
        String[] label = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
        int[] num = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26};
        int[] array = new int[size];

        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if ((col + row) % 2 == 0) {//even numbers get white pieces
                    panels[count] = new ImagePanel(brownBoard);
                } else {//odd numbers get black pieces
                    panels[count] = new ImagePanel(whiteBoard);
                }

                panels[count].setName(label[col] + num[row]);
                count++;
            }
        }

    }

    private void addComponentsToPane(Container contentPane, int size) {
        GridLayout gridLayout = new GridLayout(size, size);
        centerPanel.setLayout(gridLayout);

        //call mehod to add labels to south panel
        addLabelsToNorthPanel(size);
        //call method to add oanels to west panel
        addLabelsToWestPanel(size);
        //call method to add panels and labels to the center panel which holds the board
        addPanelsAndLabels(size);
//call method to add button to northpanel
        addLabelsToSouthPanel();

//add all panels to frame
        contentPane.add(northPanel, BorderLayout.NORTH);
        contentPane.add(centerPanel, BorderLayout.CENTER);
        contentPane.add(southPanel, BorderLayout.SOUTH);
        contentPane.add(westPanel, BorderLayout.WEST);
    }

    private void addLabelsToSouthPanel() {
        southPanel.setLayout(new FlowLayout());
        southPanel.setSize(300, 200);
        JButton next = new JButton("Next Position!");
        next.setBounds(20, 20, 40, 20);
        ButtonHandler hana = new ButtonHandler();
        next.addActionListener(hana);
        southPanel.add(next);

    }

    private class ButtonHandler implements ActionListener {

        public void actionPerformed(ActionEvent event) {

            try {
                  addPiece(new ImageIcon(ImageIO.read(new File("src\\x.png")).getScaledInstance(80, 80, Image.SCALE_SMOOTH)), goodpositions[buttoncounter]);
                  addPiece(new ImageIcon(ImageIO.read(new File("src\\knight.png")).getScaledInstance(80, 80, Image.SCALE_SMOOTH)), goodpositions[buttoncounter+1]);
                    buttoncounter++;
                
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        }
    }

    private void addLabelsToWestPanel(int size) {
        GridLayout gridLayout = new GridLayout(size, 0);

        westPanel.setLayout(gridLayout);
        JLabel[] lbls = new JLabel[size];
        int[] num = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26};
        for (int i = 0; i < size; i++) {
            lbls[i] = new JLabel(num[i] + "");
            westPanel.add(lbls[i]);
        }
    }

    private void addLabelsToNorthPanel(int size) {
        GridLayout gridLayout = new GridLayout(0, size);

        northPanel.setLayout(gridLayout);
        JLabel[] lbls = new JLabel[size];
        String[] label = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};

        for (int i = 0; i < size; i++) {
            lbls[i] = new JLabel(label[i] + "");
            northPanel.add(lbls[i]);
        }
    }

    //method sets image of a label at a certain position in the board according to the block name i.e D4
    public void addPiece(ImageIcon img, String block) {
        for (int s = 0; s < labels.length; s++) {
            if (labels[s].getName().equalsIgnoreCase(block)) {
                labels[s].setIcon(img);
            }
        }
    }

    public void addPiece(ImageIcon img, String block, String next) {
        for (int s = 0; s < labels.length; s++) {
            if (labels[s].getName().equalsIgnoreCase(block)) {
                labels[s].setIcon(img);
            }
            if (labels[s].getName().equalsIgnoreCase(next)) {
                labels[s].setIcon(img);
            }
        }
    }

//nested class used to set the background of frame contenPane
    class ImagePanel extends JPanel {

        private Image image;

        /**
         * Default constructor used to set the image for the background for the
         * instance
         */
        public ImagePanel(Image img) {
            image = img;
        }

        @Override
        protected void paintComponent(Graphics g) {
            //draws image to background to scale of frame
            g.drawImage(image, 0, 0, null);
        }
    }
}

class Knightlogic extends Chessboard {

    private static int base;
    private final static int[][] moves = {{1, -2}, {2, -1}, {2, 1}, {1, 2}, {-1, 2}, {-2, 1}, {-2, -1}, {-1, -2}};
    private static int[][] grid;
    private static int total;
    private static int rowPosition, columnPosition;
    private static int[] m;
    private static int[][] g;
    private static final String[] ro = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
    private static int sr, sc;
    private static String rnext, cnext;

    public Knightlogic(Image boardImage1, Image boardImage2, int size, int ksize, int realRowPosition, int realColumnPosition) {
        super(boardImage1, boardImage2, size, size);
        this.base = size + 4;
        this.rowPosition = realRowPosition + 2;
        this.columnPosition = realColumnPosition + 2;
    }

    public void lastLogic() {
        int b = (base - 4) * (base - 4);
        goodpositions = new String[b];
        for (int i = 0; i < b; i++) {
            goodpositions[i] = search(i + 1);
        }
        for (int i = 0; i < 64; i++) {
            System.out.println(goodpositions[i]);
        }
    }

    public static String search(int step) {
        int b = base - 4;
        String dir;
        for (int i = 0; i < b; i++) {
            for (int j = 0; j < b; j++) {
                if (g[i][j] == step) {
                    sr = j;
                    sc = i + 1;
                }
            }
        }
        rnext = ro[sr];
        cnext = Integer.toString(sc);
        dir = rnext + cnext;
        return dir;
    }

    public static void showNormalizedArrayResult() {
        int a = base - 4;
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                System.out.printf("%2d ", g[i][j]);
            }
            System.out.println();
        }
    }

    public static void InitializeResultToNormalArray() {
        int b = base - 4;
        g = new int[b][b];
        int c = 0;
        for (int i = 0; i < b; i++) {
            for (int j = 0; j < b; j++) {
                g[i][j] = m[c];
                c++;
            }
        }
    }

    public static void doLogic() {
        grid = new int[base][base];
        total = (base - 4) * (base - 4);

        for (int r = 0; r < base; r++) {
            for (int c = 0; c < base; c++) {
                if (r < 2 || r > base - 3 || c < 2 || c > base - 3) {
                    grid[r][c] = -1;
                }
            }
        }

        int row = rowPosition;
        int col = columnPosition;
        /*int row = 2 + (int) (Math.random() * (base - 4));
        int col = 2 + (int) (Math.random() * (base - 4));
         */
        grid[row][col] = 1;

        if (solve(row, col, 2)) {
            Result();
        } else {
            System.out.println("no result");
        }
        InitializeResultToNormalArray();
    }

    private static void Result() {
        m = new int[base * base];
        int c = 0;
        for (int row = 0; row < grid.length; row++) {
            for (int i = 0; i < grid[row].length; i++) {
                if (grid[row][i] == -1) {
                    continue;
                } else {
                    m[c] = grid[row][i];
                    c++;
                }
            }
        }
    }

    private static boolean solve(int r, int c, int count) {
        if (count > total) {
            return true;
        }

        java.util.List<int[]> nbrs = neighbors(r, c);

        if (nbrs.isEmpty() && count != total) {
            return false;
        }

        Collections.sort(nbrs, new Comparator<int[]>() {
            public int compare(int[] a, int[] b) {
                return a[2] - b[2];
            }
        });

        for (int[] nb : nbrs) {
            r = nb[0];
            c = nb[1];
            grid[r][c] = count;
            if (!orphanDetected(count, r, c) && solve(r, c, count + 1)) {
                return true;
            }
            grid[r][c] = 0;
        }

        return false;
    }

    private static java.util.List<int[]> neighbors(int r, int c) {
        java.util.List<int[]> nbrs = new ArrayList<>();

        for (int[] m : moves) {
            int x = m[0];
            int y = m[1];
            if (grid[r + y][c + x] == 0) {
                int num = countNeighbors(r + y, c + x);
                nbrs.add(new int[]{r + y, c + x, num});
            }
        }
        return nbrs;
    }

    private static int countNeighbors(int r, int c) {
        int num = 0;
        for (int[] m : moves) {
            if (grid[r + m[1]][c + m[0]] == 0) {
                num++;
            }
        }
        return num;
    }

    private static boolean orphanDetected(int cnt, int r, int c) {
        if (cnt < total - 1) {
            java.util.List<int[]> nbrs = neighbors(r, c);
            for (int[] nb : nbrs) {
                if (countNeighbors(nb[0], nb[1]) == 0) {
                    return true;
                }
            }
        }
        return false;
    }

}




